import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private userService:UserService, private snack:MatSnackBar) { }

  ngOnInit(): void {
  }

  public User={
    username:'',
    password:'',
    firstname:'',
    lastname:'',
    email:'',
    phone:'',
  }

  username:any;
  password:any;
  firstname:any;
  lastname:any;
  email:any;
  phone:any;
  formSubmit(){
    // alert("submit")
    if(this.User.username =='' || this.User ==null){
        this.username="UserName is Required ! "
        this.snack.open("User Name is Requred",'',{
          duration:3000,
          verticalPosition:'top',
          horizontalPosition:'center'
        })

        return;
    }

    //adduser: userServices
    this.userService.addUser(this.User).subscribe((data)=>{
      //success

      alert("success")
    },
    (error)=>{
      // alert("error")
      this.snack.open("Something Went Wrong",'',
        {
          duration:3000,
          verticalPosition:'top',
          horizontalPosition:'center'
        }
      )
    }
  );
  }




}
